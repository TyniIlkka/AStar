﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class A_Star : MonoBehaviour {

    public Transform m_tSeeker, m_tTarget;
    PathGridManager m_Grid;

    List<Node> m_lOpenSet;
    List<Node> m_lClosedSet;

    List<Node> m_lPath;
    [SerializeField]
    public Node currentNode;

    private void Awake()
    {
        m_Grid = GetComponent<PathGridManager>();
    }
	
	// Update is called once per frame
	void Update () {
        FindPath(m_tSeeker.position, m_tTarget.position);
	}

    public int GetDistance(Node a, Node b)
    {
        int iDistX = Mathf.Abs(a.m_iGridX - b.m_iGridX);
        int iDistY = Mathf.Abs(a.m_iGridY - b.m_iGridY);

        if (iDistX < iDistY)
        {
            return 14 * iDistY + 10 * (iDistX - iDistY);
        }
        else
        {
            return 14 * iDistX + 10 * (iDistY - iDistX);
        }
    }

    public void FindPath(Vector3 _vSeeker, Vector3 _vTarget)
    {


        Node startNode = m_Grid.NodeFromWorldPos(_vSeeker);
        Node endNode = m_Grid.NodeFromWorldPos(_vTarget);

        m_lOpenSet = new List<Node>();
        m_lClosedSet = new List<Node>();

        m_lOpenSet.Add(startNode);

        while (m_lOpenSet.Count > 0)
        {
            //TODO: lowest fcost
            currentNode = LowestFCostNode(m_lOpenSet);
            m_lOpenSet.Remove(currentNode);
            m_lClosedSet.Add(currentNode);
            for (int i = 1; i < m_lOpenSet.Count; i++)
            {
                if ((m_lOpenSet[i].m_ifCost < currentNode.m_ifCost) || ((m_lOpenSet[i].m_ifCost == currentNode.m_ifCost) && (m_lOpenSet[i].m_iHCost < currentNode.m_iHCost)))
                {
                    currentNode = m_lOpenSet[i];   
                }

                if (currentNode == endNode)
                {
                    Retrace(startNode, endNode);
                    return;
                }

                foreach (Node _nNeighbour in m_Grid.GetNeighbours(currentNode))
                {
                    if (_nNeighbour.m_bIsBlocked || m_lClosedSet.Contains(_nNeighbour))
                        continue;

                    int _iNewMovementCost = currentNode.m_iGCost + GetDistance(currentNode, _nNeighbour);

                    if (_nNeighbour == null)
                    {
                        Debug.Log("You have f*cked up");
                    }
                    
                    if (_iNewMovementCost < _nNeighbour.m_iGCost || !m_lOpenSet.Contains(_nNeighbour))
                    {
                        _nNeighbour.m_iGCost = _iNewMovementCost;
                        _nNeighbour.m_iHCost = GetDistance(_nNeighbour, endNode);
                        _nNeighbour.m_nParent = currentNode;

                        if (!m_lOpenSet.Contains(_nNeighbour))
                        {
                            m_lOpenSet.Add(_nNeighbour);
                        }
                    }
                }
            }
        }
    }

    public Node LowestFCostNode(List<Node> nodes)
    {
        Node result = nodes[0];
        foreach(Node node in nodes)
        {
            if (result.m_ifCost < node.m_ifCost || (result.m_ifCost == node.m_ifCost && result.m_iHCost < node.m_iHCost))
            {
                result = node;
            }
        }

        return result;
    }

    public void Retrace(Node _nStartPoint, Node _nEndPoint)
    {
        Debug.Log("Takaisin jäljitys.");
        m_lPath = new List<Node>();
        currentNode = _nEndPoint;

        while (currentNode != _nStartPoint)
        {
            m_lPath.Add(currentNode);
            currentNode = currentNode.m_nParent;
        }
        for (int i = 0; i < m_lPath.Count; i++)
        {
            Debug.Log(i);
        }
        m_lPath.Reverse();
        m_Grid.Path = m_lPath;
        if (m_Grid.Path == null)
        {
            Debug.Log("path puuttuuu");
        }
    }
}
